#ifndef GENERAR_PERSONA_HPP
#define GENERAR_PERSONA_HPP
#include <vector>

#include "persona.hpp"


Persona generarPersona();
vector <Persona> generarPersonas(const char *fichero, int numeroPersonas);

#endif //__GENERAR_ALUMNO_HPP__