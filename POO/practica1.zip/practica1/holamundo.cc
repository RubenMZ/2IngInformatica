#include<iostream>

using namespace std;

//holamundo.cc
//A program that prints the inmortal saying "hello world"

int main(){

	cout<<"hello world"<<"\n";

	return 0;

}
