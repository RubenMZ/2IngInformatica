#include "crupier.h"
#include "persona.h"
#include <string>

using namespace std;

		/*Constructor, inline en el .h*/
		/*Observadores, inline en el .h*/
		/*Modificadores, inline en el .h*/

		
